from . import ( magic, base64, tuple, simple, )
from ._delimit import ( slash, backslash, )
