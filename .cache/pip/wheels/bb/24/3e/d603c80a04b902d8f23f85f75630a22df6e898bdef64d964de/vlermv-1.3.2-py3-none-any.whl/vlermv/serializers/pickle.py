from pickle import load, dump
binary_mode = True
